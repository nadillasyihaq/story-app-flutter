// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'country_lang.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CountryLang _$CountryLangFromJson(Map<String, dynamic> json) => CountryLang(
      flag: json['flag'] as String,
      country: json['country'] as String,
      countryCode: json['countryCode'] as String,
    );

Map<String, dynamic> _$CountryLangToJson(CountryLang instance) =>
    <String, dynamic>{
      'flag': instance.flag,
      'country': instance.country,
      'countryCode': instance.countryCode,
    };
