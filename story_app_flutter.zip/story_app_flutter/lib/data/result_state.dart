enum ResultState {
  initial,
  loading,
  loaded,
  noData,
  error,
}
